const { contextBridge, ipcRenderer } = require('electron')

// process jest globalnym obiektem Node.js — nie pochodzi z modułu 'electron'
const isPrivateWindow = Array.isArray(process.argv) && process.argv.includes('--nitrix-private')

// ── Helpery walidacji ─────────────────────────────────────────────────
const isString  = (v) => typeof v === 'string'
const isNumber  = (v) => typeof v === 'number' && Number.isFinite(v)
const isObject  = (v) => v !== null && typeof v === 'object' && !Array.isArray(v)
const isArray   = (v) => Array.isArray(v)

// Bezpieczna ścieżka — tylko string, bez null bytes
const isSafePath = (v) => isString(v) && v.length > 0 && !v.includes('\0')

// Hostname — tylko litery, cyfry, myślniki, kropki
const isSafeHostname = (v) => isString(v) && /^[a-zA-Z0-9.\-]{1,253}$/.test(v)

// Walidacja kształtu wpisu historii
function isValidHistoryEntry(e) {
  if (!isObject(e)) return false
  if (!isString(e.url) || e.url.length > 2048) return false
  if (!isString(e.title) || e.title.length > 512) return false
  if (!isNumber(e.timestamp)) return false
  return true
}

// Walidacja kształtu zakładki
function isValidBookmark(b) {
  if (!isObject(b)) return false
  if (!isString(b.name) || b.name.length > 512) return false
  if (!isString(b.url)  || b.url.length > 2048) return false
  return true
}

// Walidacja obiektu ustawień — tylko znane klucze, znane typy
const ALLOWED_THEMES    = ['dark', 'light', 'private']
const ALLOWED_ENGINES   = ['google', 'duckduckgo', 'bing', 'brave', 'ecosia', 'yahoo', 'custom']
const ALLOWED_BKBAR     = ['always', 'newtab', 'never']
const ALLOWED_PRIVSUGG  = ['all', 'history', 'bookmarks', 'none']
const ALLOWED_HOMEPAGE  = ['google', 'duckduckgo', 'bing', 'custom']

function isValidSettings(s) {
  if (!isObject(s)) return false
  if ('theme'                  in s && !ALLOWED_THEMES.includes(s.theme))                   return false
  if ('searchEngine'           in s && !ALLOWED_ENGINES.includes(s.searchEngine))            return false
  if ('bkBarMode'              in s && !ALLOWED_BKBAR.includes(s.bkBarMode))                 return false
  if ('privateSuggestionsMode' in s && !ALLOWED_PRIVSUGG.includes(s.privateSuggestionsMode)) return false
  if ('homepage'               in s && !ALLOWED_HOMEPAGE.includes(s.homepage))               return false
  if ('expandBar'              in s && typeof s.expandBar           !== 'boolean') return false
  if ('historySuggestions'     in s && typeof s.historySuggestions  !== 'boolean') return false
  if ('bookmarkSuggestions'    in s && typeof s.bookmarkSuggestions !== 'boolean') return false
  if ('homepageUrl'            in s && (!isString(s.homepageUrl)         || s.homepageUrl.length > 2048))       return false
  if ('customHomepageUrl'      in s && (!isString(s.customHomepageUrl)   || s.customHomepageUrl.length > 2048)) return false
  return true
}

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  close:    () => ipcRenderer.send('window-close'),

  // ── Ustawienia ──
  loadSettings: () => ipcRenderer.invoke('settings-load'),
  saveSettings: (data) => {
    if (!isValidSettings(data)) return Promise.resolve(false)
    return ipcRenderer.invoke('settings-save', data)
  },

  // ── Zakładki ──
  loadBookmarks: () => ipcRenderer.invoke('bookmarks-load'),
  saveBookmarks: (data) => {
    if (!isArray(data) || !data.every(isValidBookmark)) return Promise.resolve(false)
    return ipcRenderer.invoke('bookmarks-save', data)
  },

  // ── Historia ──
  loadHistory:   () => ipcRenderer.invoke('history-load'),
  addHistory:    (entry) => {
    if (!isValidHistoryEntry(entry)) return Promise.resolve(false)
    return ipcRenderer.invoke('history-add', entry)
  },
  deleteHistory: (timestamp) => {
    if (!isNumber(timestamp)) return Promise.resolve(false)
    return ipcRenderer.invoke('history-delete', timestamp)
  },
  clearHistory: () => ipcRenderer.invoke('history-clear'),

  // ── Pobieranie — tylko odbiór zdarzeń z main procesu ──
  // Używamy removeAllListeners przed on() żeby nie akumulować listenerów
  // przy wielokrotnym wywołaniu (np. po hot-reload w dev)
  onDownloadStarted:  (cb) => {
    ipcRenderer.removeAllListeners('download-started')
    ipcRenderer.on('download-started',  (_e, data) => cb(data))
  },
  onDownloadProgress: (cb) => {
    ipcRenderer.removeAllListeners('download-progress')
    ipcRenderer.on('download-progress', (_e, data) => cb(data))
  },
  onDownloadDone:     (cb) => {
    ipcRenderer.removeAllListeners('download-done')
    ipcRenderer.on('download-done',     (_e, data) => cb(data))
  },

  // ── Plik — tylko pliki z folderu pobrań, z resolwowaniem ścieżki ──
  openFile:     (filePath) => {
    if (!isSafePath(filePath)) return Promise.resolve(false)
    return ipcRenderer.invoke('open-file', filePath)
  },
  showInFolder: (filePath) => {
    if (!isSafePath(filePath)) return Promise.resolve(false)
    return ipcRenderer.invoke('show-in-folder', filePath)
  },
  fileExists:   (filePath) => {
    if (!isSafePath(filePath)) return Promise.resolve({ exists: false, mtimeMs: 0 })
    return ipcRenderer.invoke('file-exists', filePath)
  },

  // ── Auto-update ──
  onUpdateStatus: (cb) => {
    ipcRenderer.removeAllListeners('update-status')
    ipcRenderer.on('update-status', (_e, data) => cb(data))
  },
  installUpdate:  () => ipcRenderer.send('update-install-now'),
  downloadUpdate: () => ipcRenderer.send('update-download-now'),
  dismissUpdate:  () => ipcRenderer.send('update-dismiss'),

  // ── Certyfikat ──
  getCertInfo: (hostname) => {
    if (!isSafeHostname(hostname)) return Promise.resolve(null)
    return ipcRenderer.invoke('get-cert-info', hostname)
  },

  // ── RAM ──
  getRamUsage: (webContentsId) => {
    if (!isNumber(webContentsId)) return Promise.resolve({ mb: null })
    return ipcRenderer.invoke('get-ram-usage', webContentsId)
  },

  // ── Menu kontekstowe ──
  showContextMenu:     () => ipcRenderer.send('show-context-menu'),
  onContextMenuAction: (cb) => {
    ipcRenderer.removeAllListeners('context-menu-action')
    ipcRenderer.on('context-menu-action', (_e, action) => cb(action))
  },

  // ── Nowa karta z linku ──
  onOpenInNewTab: (cb) => {
    ipcRenderer.removeAllListeners('open-in-new-tab')
    ipcRenderer.on('open-in-new-tab', (_e, url) => {
      if (isString(url) && /^https?:\/\//i.test(url)) cb(url)
    })
  },

  // ── DevTools strony w webview ──
  openWebviewDevTools: (webContentsId) => {
    if (!isNumber(webContentsId)) return
    ipcRenderer.send('open-webview-devtools', webContentsId)
  },

  // ── Tryb prywatny ──
  isPrivate:         isPrivateWindow,
  openPrivateWindow: () => ipcRenderer.send('open-private-window'),

  // ── Niszczyciel Nitrix — usuń wszystkie dane przeglądarki ──
  nitrixDestroy: (options) => {
    if (!isObject(options)) return Promise.resolve(false)
    return ipcRenderer.invoke('nitrix-destroy', {
      clearHistory:   !!options.clearHistory,
      clearBookmarks: !!options.clearBookmarks,
      clearCookies:   !!options.clearCookies,
      clearCache:     !!options.clearCache,
      clearStorage:   !!options.clearStorage,
    })
  },

  // ── Zapisz stronę / obraz ──
  savePage: (webContentsId, title, url, context, pageUrl) => {
    if (!isNumber(webContentsId)) return Promise.resolve(false)
    if (!isString(title))   title   = 'strona'
    if (!isString(url))     url     = ''
    if (!isString(context)) context = 'page'
    if (!['page', 'image'].includes(context)) context = 'page'
    if (!isString(pageUrl)) pageUrl = ''
    return ipcRenderer.invoke('save-page', { webContentsId, title, url, context, pageUrl })
  },
})