const { app, BrowserWindow, ipcMain, session, shell, Menu, dialog } = require('electron')
const path = require('path')
const fs   = require('fs')
const { autoUpdater } = require('electron-updater')

// ── Folder danych — MUSI być przed app.ready i przed wszystkim ────────
const dataDir = path.join(app.getPath('appData'), 'Nitrix')
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true })
app.setPath('userData', dataDir)

// ── Pojedyncza instancja — zapobiega konfliktom cache ─────────────────
// Gdy użytkownik kliknie ikonę po raz drugi, zamiast nowego procesu
// (który blokuje cache) otworzy się nowe okno w tej samej instancji.
const gotTheLock = app.requestSingleInstanceLock()
if (!gotTheLock) {
  // Jesteśmy drugą instancją — kończymy się, pierwsza otworzy nowe okno
  app.quit()
}

app.commandLine.appendSwitch('site-per-process')

// ── Flagi Chromium ────────────────────────────────────────────────────
app.commandLine.appendSwitch('enable-quic')
app.commandLine.appendSwitch('quic-version', 'h3')
app.commandLine.appendSwitch('enable-features',
  'NetworkServiceInProcess,ParallelDownloading,PrefetchDNSWithURLRequests,AsyncDns,TcpFastOpenConnectRetry,V8VmFuture,SitePerProcess,StrictOriginIsolation,IsolateOrigins'
)
app.commandLine.appendSwitch('disable-features',
  // BackForwardCache     — trzyma pełny snapshot strony w RAM przy każdym cofnięciu/powrocie; wyłączenie = największy zysk
  // GlobalMediaControls  — tło-serwis dla kontroli mediów systemowych; zbędny w przeglądarce desktopowej
  // HardwareMediaKeyHandling — rejestruje globalne handlery klawiszy mediów; kolejny zbędny serwis
  'TranslateUI,MediaRouter,DialMediaRouteProvider,AutofillServerCommunication,OptimizationHints,Translate,HeavyAdIntervention,LazyImageLoading,BackForwardCache,GlobalMediaControls,HardwareMediaKeyHandling,CalculateNativeWinOcclusion,ThrottleDisplayNoneVisibility'
)
app.commandLine.appendSwitch('disk-cache-size',  String(256 * 1024 * 1024))
app.commandLine.appendSwitch('media-cache-size', String(128 * 1024 * 1024))
// --turbofan jest domyślny w V8 od lat — usunięto jako redundantny
// --max-semi-space-size=64 ogranicza młodą generację GC (domyślnie może rosnąć do 512 MB)
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=512 --max-semi-space-size=64')
app.commandLine.appendSwitch('enable-gpu-rasterization')
app.commandLine.appendSwitch('enable-zero-copy')
app.commandLine.appendSwitch('ignore-gpu-blocklist')
app.commandLine.appendSwitch('enable-accelerated-video-decode')
app.commandLine.appendSwitch('enable-accelerated-2d-canvas')
app.commandLine.appendSwitch('max-connections-per-proxy', '32')
app.commandLine.appendSwitch('host-resolver-rules', '')
app.commandLine.appendSwitch('disable-background-networking', 'false')
// Zmniejszono z 6 → 4; każdy renderer to ~30–80 MB; 4 wystarczy dla typowego użycia
app.commandLine.appendSwitch('renderer-process-limit', '4')

// ── Pliki danych ──────────────────────────────────────────────────────
const settingsFile  = path.join(dataDir, 'settings.json')
const bookmarksFile = path.join(dataDir, 'bookmarks.json')
const historyFile   = path.join(dataDir, 'history.json')

function loadSettings() {
  try {
    if (fs.existsSync(settingsFile))
      return JSON.parse(fs.readFileSync(settingsFile, 'utf8'))
  } catch(e) {}
  return { theme: 'light' }
}
function saveSettings(data) {
  try {
    const current = loadSettings()
    // Object.create(null) zapobiega prototype pollution
    const safe = Object.assign(Object.create(null), current)
    const ALLOWED_KEYS = ['theme','expandBar','bkBarMode','searchEngine','homepage',
      'homepageUrl','customHomepageUrl','historySuggestions','bookmarkSuggestions','privateSuggestionsMode']
    for (const key of ALLOWED_KEYS) {
      if (key in data) safe[key] = data[key]
    }
    fs.writeFileSync(settingsFile, JSON.stringify(safe, null, 2))
  } catch(e) {}
}

function loadBookmarks() {
  try {
    if (fs.existsSync(bookmarksFile))
      return JSON.parse(fs.readFileSync(bookmarksFile, 'utf8'))
  } catch(e) {}
  return []
}
function saveBookmarks(data) {
  try { fs.writeFileSync(bookmarksFile, JSON.stringify(data, null, 2)) } catch(e) {}
}

function loadHistory() {
  try {
    if (fs.existsSync(historyFile))
      return JSON.parse(fs.readFileSync(historyFile, 'utf8'))
  } catch(e) {}
  return []
}
function saveHistory(data) {
  try { fs.writeFileSync(historyFile, JSON.stringify(data, null, 2)) } catch(e) {}
}

let _historyCache = null
let _historySaveTimer = null

function getHistoryCache() {
  if (_historyCache === null) _historyCache = loadHistory()
  return _historyCache
}
function scheduleSaveHistory() {
  if (_historySaveTimer) clearTimeout(_historySaveTimer)
  _historySaveTimer = setTimeout(() => {
    if (_historyCache !== null) {
      saveHistory(_historyCache)
      // Zwolnij cache z RAM po zapisie — przy następnym odczycie wczyta się z dysku
      _historyCache = null
    }
  }, 1000)
}

function addHistoryEntry(entry) {
  try {
    const history = getHistoryCache()
    const now = Date.now()
    const idx = history.findIndex(h => h.url === entry.url && now - h.timestamp < 5000)
    if (idx !== -1) {
      if (entry.title && entry.title !== entry.url) history[idx].title = entry.title
      scheduleSaveHistory()
      return
    }
    history.unshift(entry)
    if (history.length > 5000) history.splice(5000)
    scheduleSaveHistory()
  } catch(e) {}
}

// ── Handlery IPC ──────────────────────────────────────────────────────
// ── Menu kontekstowe ──────────────────────────────────────────────────
ipcMain.on('show-context-menu', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender)
  const menu = Menu.buildFromTemplate([
    {
      label: '↺  Odśwież',
      click: () => { event.sender.send('context-menu-action', 'refresh') }
    }
  ])
  menu.popup({ window: win })
})

ipcMain.on('open-webview-devtools', (e, webContentsId) => {
  const { webContents } = require('electron')
  const wc = webContents.fromId(webContentsId)
  if (!wc || wc.isDestroyed()) return
  if (wc.isDevToolsOpened()) {
    wc.closeDevTools()
  } else {
    wc.openDevTools({ mode: 'detach' })
  }
})

ipcMain.on('window-minimize', () => {
  const win = BrowserWindow.getFocusedWindow()
  if (win) win.minimize()
})
ipcMain.on('window-maximize', () => {
  const win = BrowserWindow.getFocusedWindow()
  if (win) win.isMaximized() ? win.unmaximize() : win.maximize()
})
ipcMain.on('window-close', () => {
  const win = BrowserWindow.getFocusedWindow()
  if (win) win.destroy()
})

ipcMain.handle('settings-load',  () => loadSettings())
ipcMain.handle('settings-save',  (e, data) => { saveSettings(data); return true })
ipcMain.handle('bookmarks-load', () => loadBookmarks())
ipcMain.handle('bookmarks-save', (e, data) => { saveBookmarks(data); return true })

ipcMain.handle('history-load',   () => getHistoryCache())
ipcMain.handle('history-add',    (e, entry) => { addHistoryEntry(entry); return true })
ipcMain.handle('history-delete', (e, timestamp) => {
  _historyCache = getHistoryCache().filter(h => h.timestamp !== timestamp)
  scheduleSaveHistory()
  return true
})
ipcMain.handle('history-clear',  () => { _historyCache = []; scheduleSaveHistory(); return true })

// ── Niszczyciel Nitrix — permanentne czyszczenie danych ───────────────
ipcMain.handle('nitrix-destroy', async (e, opts) => {
  if (!opts || typeof opts !== 'object') return false

  // 1. Historia — wyczyść cache i plik
  if (opts.clearHistory) {
    _historyCache = []
    try { fs.writeFileSync(historyFile, '[]') } catch(err) { console.error('[Niszczyciel] historia:', err) }
  }

  // 2. Zakładki — wyczyść plik
  if (opts.clearBookmarks) {
    try { fs.writeFileSync(bookmarksFile, '[]') } catch(err) { console.error('[Niszczyciel] zakładki:', err) }
  }

  // 3. Dane sesji: cookies, localStorage, IndexedDB, itp.
  const mainSession = session.fromPartition('persist:main')

  if (opts.clearCookies || opts.clearStorage) {
    const storages = []
    if (opts.clearCookies) storages.push('cookies', 'serviceworkers', 'shadercache')
    if (opts.clearStorage) storages.push('localstorage', 'indexdb', 'websql',
                                         'cachestorage', 'appcache', 'filesystem')
    try {
      await mainSession.clearStorageData({ storages })
    } catch(err) { console.error('[Niszczyciel] storage:', err) }
  }

  // 4. Cache HTTP (obrazy, skrypty, zasoby)
  if (opts.clearCache) {
    try { await mainSession.clearCache() } catch(err) { console.error('[Niszczyciel] cache:', err) }
  }

  return true
})
// ── Koniec Niszczyciela ───────────────────────────────────────────────
ipcMain.handle('open-file', (e, filePath) => {
  if (!filePath) return false
  const resolved  = path.resolve(filePath)
  const downloads = path.resolve(app.getPath('downloads'))
  if (!resolved.startsWith(downloads + path.sep) && resolved !== downloads) return false
  shell.openPath(resolved)
  return true
})

// ── Pokaż plik w eksploratorze ────────────────────────────────────
ipcMain.handle('show-in-folder', (e, filePath) => {
  if (!filePath) return false
  const resolved  = path.resolve(filePath)
  const downloads = path.resolve(app.getPath('downloads'))
  if (!resolved.startsWith(downloads + path.sep) && resolved !== downloads) return false
  shell.showItemInFolder(resolved)
  return true
})

// ── Sprawdź plik — tylko folder pobrań ───────────────────────────
ipcMain.handle('file-exists', (e, filePath) => {
  if (!filePath) return { exists: false, mtimeMs: 0 }
  const resolved  = path.resolve(filePath)
  const downloads = path.resolve(app.getPath('downloads'))
  if (!resolved.startsWith(downloads + path.sep) && resolved !== downloads)
    return { exists: false, mtimeMs: 0 }
  try {
    const stat = fs.statSync(resolved)
    return { exists: true, mtimeMs: stat.mtimeMs }
  } catch { return { exists: false, mtimeMs: 0 } }
})

// ── Zapisz stronę / obraz ────────────────────────────────────────
ipcMain.handle('save-page', async (e, { webContentsId, title, url, context, pageUrl }) => {
  const { webContents, net } = require('electron')
  const wc = webContents.fromId(webContentsId)
  if (!wc) return false

  const win = BrowserWindow.fromWebContents(e.sender) || BrowserWindow.getFocusedWindow()
  const send = (ch, data) => { if (win && !win.isDestroyed()) win.webContents.send(ch, data) }
  const dlId = ++downloadIdCounter

  // ── Zapisz obraz ──────────────────────────────────────────────
  if (context === 'image' && url) {
    const isDataUrl = url.startsWith('data:')
    const isBlobUrl = url.startsWith('blob:')
    const isHttpUrl = /^https?:\/\//i.test(url)

    if (!isDataUrl && !isBlobUrl && !isHttpUrl) return false

    // ── Inteligentna nazwa pliku (jak Chrome) ──────────────────
    let imgName = ''
    let imgExt  = 'jpg'

    if (isHttpUrl) {
      try {
        const u = new URL(url)
        const base = path.basename(u.pathname)

        if (/\.(jpe?g|png|gif|webp|svg|bmp|avif|tiff?)$/i.test(base)) {
          // Ścieżka ma rozszerzenie obrazka — użyj jej
          imgName = base
          imgExt  = path.extname(base).replace('.', '').toLowerCase()
        } else if (base && base !== '/' && base.length > 1 && !base.includes('.')) {
          // Ścieżka ma nazwę bez rozszerzenia — użyj jej + dodaj rozszerzenie
          imgName = base + '.jpg'
        } else {
          // Brak użytecznej nazwy w ścieżce — użyj domeny OBRAZKA (nie strony)
          const imgDomain = u.hostname.replace(/^www\./, '')
          imgName = imgDomain + '.jpg'
        }
      } catch {}
    }

    if (isDataUrl) {
      const mimeMatch = url.match(/^data:image\/([a-z0-9+]+);/)
      if (mimeMatch) {
        imgExt  = mimeMatch[1] === 'jpeg' ? 'jpg' : mimeMatch[1]
        imgName = 'obraz.' + imgExt
      }
    }

    // Fallback dla blob: — użyj domeny strony
    if (!imgName) {
      try {
        const domain = new URL(pageUrl || url).hostname.replace(/^www\./, '')
        imgName = (domain || 'obraz') + '.' + imgExt
      } catch {
        imgName = 'obraz.' + imgExt
      }
    }

    imgName = imgName.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 100)

    const { canceled, filePath } = await dialog.showSaveDialog(win, {
      title:       'Zapisz obraz jako',
      defaultPath: path.join(app.getPath('downloads'), imgName),
      filters: [
        { name: 'Obraz',           extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'] },
        { name: 'Wszystkie pliki', extensions: ['*'] },
      ],
    })
    if (canceled || !filePath) return false

    const filename = path.basename(filePath)
    send('download-started', { id: dlId, filename, totalBytes: 0 })

    try {
      // ── data: URL — dekoduj base64 bezpośrednio ──
      if (isDataUrl) {
        const base64Match = url.match(/^data:[^;]+;base64,(.+)$/)
        if (!base64Match) throw new Error('Nieprawidłowy data URL')
        const buf = Buffer.from(base64Match[1], 'base64')
        fs.writeFileSync(filePath, buf)
        send('download-done', { id: dlId, filename, state: 'completed', savePath: filePath, totalBytes: buf.length })
        shell.showItemInFolder(filePath)
        return true
      }

      // ── blob: lub http/https — użyj executeJavaScript w webview ──
      // Dla blob: pobieramy przez renderer (blob: nie jest dostępny z main procesu)
      if (isBlobUrl) {
        const base64 = await wc.executeJavaScript(`
          new Promise((resolve, reject) => {
            fetch(${JSON.stringify(url)})
              .then(r => r.blob())
              .then(blob => {
                const reader = new FileReader()
                reader.onload = () => resolve(reader.result.split(',')[1])
                reader.onerror = reject
                reader.readAsDataURL(blob)
              })
              .catch(reject)
          })
        `)
        const buf = Buffer.from(base64, 'base64')
        fs.writeFileSync(filePath, buf)
        send('download-done', { id: dlId, filename, state: 'completed', savePath: filePath, totalBytes: buf.length })
        shell.showItemInFolder(filePath)
        return true
      }

      // ── http/https — pobierz przez net.request ──
      return await new Promise((resolve) => {
        const req = net.request({ url, useSessionCookies: true })
        const chunks = []
        let received = 0
        req.on('response', (resp) => {
          const total = parseInt(resp.headers['content-length'] || '0', 10) || 0
          resp.on('data', (chunk) => {
            chunks.push(chunk)
            received += chunk.length
            send('download-progress', { id: dlId, filename, receivedBytes: received, totalBytes: total, speed: 0 })
          })
          resp.on('end', () => {
            try {
              fs.writeFileSync(filePath, Buffer.concat(chunks))
              send('download-done', { id: dlId, filename, state: 'completed', savePath: filePath, totalBytes: received })
              shell.showItemInFolder(filePath)
              resolve(true)
            } catch {
              send('download-done', { id: dlId, filename, state: 'interrupted', savePath: filePath, totalBytes: 0 })
              resolve(false)
            }
          })
        })
        req.on('error', () => {
          send('download-done', { id: dlId, filename, state: 'interrupted', savePath: filePath, totalBytes: 0 })
          resolve(false)
        })
        req.end()
      })
    } catch (err) {
      console.error('[save-page image]', err.message)
      send('download-done', { id: dlId, filename, state: 'interrupted', savePath: filePath, totalBytes: 0 })
      return false
    }
  }

  // ── Zapisz stronę ─────────────────────────────────────────────
  const safeName = (title || 'strona')
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 100) || 'strona'

  let defaultExt = 'html'
  try {
    if (new URL(url).pathname.toLowerCase().endsWith('.pdf')) defaultExt = 'pdf'
  } catch {}

  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title:       'Zapisz jako',
    defaultPath: path.join(app.getPath('downloads'), safeName + '.' + defaultExt),
    filters: [
      { name: 'Strona internetowa',       extensions: ['html', 'htm'] },
      { name: 'Strona (pojedynczy plik)', extensions: ['mhtml', 'mht'] },
      { name: 'Dokument PDF',             extensions: ['pdf'] },
      { name: 'Zrzut ekranu (JPEG)',      extensions: ['jpg', 'jpeg'] },
      { name: 'Wszystkie pliki',          extensions: ['*'] },
    ],
  })
  if (canceled || !filePath) return false

  const filename = path.basename(filePath)
  const ext = path.extname(filePath).toLowerCase().replace('.', '')

  send('download-started', { id: dlId, filename, totalBytes: 0 })

  try {
    if (ext === 'pdf') {
      const data = await wc.printToPDF({ printBackground: true, pageSize: 'A4' })
      fs.writeFileSync(filePath, data)
    } else if (ext === 'mhtml' || ext === 'mht') {
      await wc.savePage(filePath, 'MHTML')
    } else if (ext === 'jpg' || ext === 'jpeg') {
      const image = await wc.capturePage()
      fs.writeFileSync(filePath, image.toJPEG(92))
    } else {
      await wc.savePage(filePath, 'HTMLComplete')
    }
    const totalBytes = (() => { try { return fs.statSync(filePath).size } catch { return 0 } })()
    send('download-done', { id: dlId, filename, state: 'completed', savePath: filePath, totalBytes })
    shell.showItemInFolder(filePath)
    return true
  } catch (err) {
    console.error('[save-page]', err.message)
    send('download-done', { id: dlId, filename, state: 'interrupted', savePath: filePath, totalBytes: 0 })
    return false
  }
})
// Cache metryk — app.getAppMetrics() jest kosztowne; odświeżaj max raz na 3 sekundy
let _metricsCache = null
let _metricsCacheTime = 0
async function getCachedMetrics() {
  const now = Date.now()
  if (_metricsCache && now - _metricsCacheTime < 3000) return _metricsCache
  _metricsCache = await app.getAppMetrics()
  _metricsCacheTime = now
  return _metricsCache
}

ipcMain.handle('get-ram-usage', async (e, webContentsId) => {
  try {
    const all = await getCachedMetrics()
    if (webContentsId != null) {
      const { webContents } = require('electron')
      const wc = webContents.fromId(webContentsId)
      if (wc) {
        const pid = wc.getOSProcessId()
        const proc = all.find(p => p.pid === pid)
        if (proc) {
          const mb = Math.round((proc.memory?.workingSetSize || 0) / 1024)
          return { mb }
        }
      }
    }
    // fallback — suma wszystkich
    const totalKB = all.reduce((sum, p) => sum + (p.memory?.workingSetSize || 0), 0)
    return { mb: Math.round(totalKB / 1024) }
  } catch { return { mb: null } }
})

// ══════════════════════════════════════════════════════════════════════
//  OBSŁUGA POBIERANIA PLIKÓW — NOWE
// ══════════════════════════════════════════════════════════════════════
let downloadIdCounter = 0

function setupDownloadHandling(win, wvSession) {
  const send = (channel, data) => {
    if (!win.isDestroyed()) win.webContents.send(channel, data)
  }

  wvSession.on('will-download', (event, item) => {
    // Jeśli okno już nie istnieje — anuluj pobieranie natychmiast
    if (win.isDestroyed()) { item.cancel(); return }

    const dlId = ++downloadIdCounter
    let lastBytes = 0
    let lastTime  = Date.now() - 200
    let speedSamples = []

    // Powiadom renderer że zaczęło się pobieranie
    send('download-started', {
      id:         dlId,
      filename:   item.getFilename(),
      totalBytes: item.getTotalBytes(),
    })

    item.on('updated', () => {
      if (win.isDestroyed()) return
      const now      = Date.now()
      const received = item.getReceivedBytes()
      const total    = item.getTotalBytes()
      const dt = (now - lastTime) / 1000
      const db = received - lastBytes

      // Zwiększono próg 0.1s → 0.3s — IPC co 300ms zamiast 100ms; pasek postępu działa tak samo
      if (dt >= 0.3) {
        if (db > 0) speedSamples.push(db / dt)
        if (speedSamples.length > 8) speedSamples.shift()
        lastBytes = received
        lastTime  = now

        const speed = speedSamples.length
          ? speedSamples.reduce((a, b) => a + b, 0) / speedSamples.length
          : 0

        send('download-progress', {
          id:            dlId,
          filename:      item.getFilename(),
          receivedBytes: received,
          totalBytes:    total,
          speed,
        })
      }
    })

    item.once('done', (e, state) => {
      send('download-done', {
        id:         dlId,
        filename:   item.getFilename(),
        state,
        savePath:   item.getSavePath(),
        totalBytes: item.getTotalBytes(),
      })
    })
  })
}

// ── Tworzenie okna ────────────────────────────────────────────────────
// ── Cache certyfikatów — globalny, współdzielony ─────────────────
const crypto = require('crypto')
const CERT_CACHE_MAX = 150
const certCache = new Map()

function certCacheSet(hostname, value) {
  if (certCache.size >= CERT_CACHE_MAX) {
    // Usuń najstarszy wpis (Map zachowuje kolejność wstawiania)
    certCache.delete(certCache.keys().next().value)
  }
  certCache.set(hostname, value)
}

ipcMain.handle('get-cert-info', (e, hostname) => {
  return certCache.get(hostname) || null
})

function createWindow(isPrivate = false) {
  const settings = loadSettings()

  // Tryb prywatny — unikalna sesja in-memory, bez żadnej persystencji
  const sessionPartition = isPrivate
    ? `private:${Date.now()}`   // bez 'persist:' → tylko RAM, kasowana przy zamknięciu
    : 'persist:main'

  const win = new BrowserWindow({
    width: 1280, height: 800,
    minWidth: 900, minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: isPrivate ? '#1a1035' : (settings.theme === 'dark' ? '#202124' : '#f1f3f4'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      // sandbox: false wymagane — preload.js używa require('electron') do contextBridge.
      // Bezpieczeństwo zapewnia contextIsolation: true + brak nodeIntegration w rendererze.
      sandbox: false,
      webviewTag: true,
      backgroundThrottling: true,
      // 'code' zamiast 'bypassHeatCheck' — mniej agresywne cache'owanie bajtkodu V8, mniejszy heap
      v8CacheOptions: 'code',
      additionalArguments: isPrivate ? ['--nitrix-private'] : [],
    },
  })

  win.loadFile('index.html')
  win.maximize()

  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))

  const wvSession = session.fromPartition(sessionPartition)

  // Blokuj nawigację do niebezpiecznych schematów na poziomie sesji
  function blockUnsafeNavigation(sess) {
    sess.webRequest.onBeforeRequest({ urls: ['file://*/*', 'javascript:*', 'data:*', 'blob:*', 'vbscript:*'] },
      (details, callback) => {
        const url = details.url || ''
        if (/^(file|javascript|vbscript):/.test(url)) {
          callback({ cancel: true })
        } else {
          callback({ cancel: false })
        }
      }
    )
  }

  // Wymuszaj nagłówki izolacji między originami na odpowiedziach HTTP
  function applyIsolationHeaders(sess) {
    sess.webRequest.onHeadersReceived((details, callback) => {
      const raw = details.responseHeaders

      // Sprawdź content-type BEZ kopiowania — unikamy drogiego spreadu dla każdego zasobu
      const ct = (raw['content-type'] || raw['Content-Type'] || [''])[0] || ''
      const isDocument = ct.includes('text/html') || ct.includes('application/xhtml')

      // Dla nie-dokumentów (obrazki, fonty, JS, CSS z CDN) — zwróć oryginał bez kopii
      if (!isDocument) { callback({ responseHeaders: raw }); return }

      // Nagłówek już istnieje — nic nie zmieniaj
      if (raw['cross-origin-opener-policy']) { callback({ responseHeaders: raw }); return }

      // Tylko dla dokumentów HTML bez nagłówka — dopiero teraz rób kopię
      const headers = { ...raw }
      headers['cross-origin-opener-policy'] = ['same-origin']
      callback({ responseHeaders: headers })
    })
  }

  blockUnsafeNavigation(wvSession)
  applyIsolationHeaders(wvSession)

  // Tryb prywatny — wyłącz cache i cookies całkowicie
  if (isPrivate) {
    wvSession.clearStorageData()
    wvSession.setPermissionRequestHandler((webContents, permission, callback) => {
      // Zezwól na podstawowe uprawnienia, blokuj śledzące
      const allowed = ['media', 'geolocation', 'notifications', 'fullscreen', 'pointerLock']
      callback(allowed.includes(permission))
    })
  }

  // setCertificateVerifyProc tylko raz per sesja
  if (!wvSession.listenerCount('did-fail-load')) {
    wvSession.setCertificateVerifyProc((request, callback) => {
      try {
        const pem = request.certificate.data
        const derBase64 = pem.replace(/-----BEGIN CERTIFICATE-----|-----END CERTIFICATE-----|\s/g, '')
        const der = Buffer.from(derBase64, 'base64')
        const sha256 = crypto.createHash('sha256').update(der).digest('hex')
        let pkSha256 = null
        try {
          const x509 = new crypto.X509Certificate(pem)
          const spki = x509.publicKey.export({ type: 'spki', format: 'der' })
          pkSha256 = crypto.createHash('sha256').update(spki).digest('hex')
        } catch(e) {}
        certCacheSet(request.hostname, {
          cert: request.certificate, valid: request.errorCode === 0,
          error: request.error || null, sha256, pkSha256,
        })
      } catch(e) {
        certCacheSet(request.hostname, {
          cert: request.certificate, valid: request.errorCode === 0,
          error: request.error || null, sha256: null, pkSha256: null,
        })
      }
      callback(-3)
    })

    if (!isPrivate) {
      const topDomains = [
        'https://www.google.pl', 'https://www.google.com',
        'https://www.youtube.com', 'https://accounts.google.com',
      ]
      topDomains.forEach(url => {
        // Zmniejszono numSockets: 2 → 1 — mniej buforowanych połączeń w RAM
        try { wvSession.preconnect({ url, numSockets: 1 }) } catch(e) {}
      })
    }
  }

  setupDownloadHandling(win, wvSession)

  // W trybie prywatnym webview używa sesji 'persist:nitrix_private'
  // (persist zamiast in-memory — inaczej wbudowany PDF viewer Chromium nie działa).
  // Prywatność zapewnia clearStorageData() przy każdym otwarciu i zamknięciu okna.
  if (isPrivate) {
    const wvPrivateSession = session.fromPartition('persist:nitrix_private')

    // Wyczyść dane z poprzedniej sesji prywatnej
    wvPrivateSession.clearStorageData()
    wvPrivateSession.clearCache()
    wvPrivateSession.clearAuthCache()

    blockUnsafeNavigation(wvPrivateSession)
    applyIsolationHeaders(wvPrivateSession)

    wvPrivateSession.removeAllListeners('will-download')
    setupDownloadHandling(win, wvPrivateSession)

    // Sprzątanie przy zamknięciu — usuń wszelkie pozostałości
    win.on('closed', () => {
      wvPrivateSession.removeAllListeners('will-download')
      wvPrivateSession.clearStorageData()
      wvPrivateSession.clearCache()
      wvPrivateSession.clearAuthCache()
    })
  }
}

// ── IPC: otwórz okno prywatne ─────────────────────────────────────────
ipcMain.on('open-private-window', () => {
  createWindow(true)
})

// ── Druga instancja próbuje się uruchomić → otwórz nowe okno ─────────
app.on('second-instance', () => {
  createWindow()
})

// ── Wycisz ostrzeżenie CSP w trybie deweloperskim ────────────────────
// Electron wyrzuca "Insecure Content-Security-Policy" dla protokołu file://
// ponieważ nagłówki HTTP nie istnieją przy loadFile() — <meta> CSP tag
// jest ignorowany przez ten check. Ostrzeżenie NIE pojawia się w spakowanej
// aplikacji (.exe). Flaga wyłącza tylko komunikaty devtools, nie zmienia zabezpieczeń.
process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = '1'

app.whenReady().then(() => {
  if (gotTheLock) {
    // Ustaw priorytet poniżej normalnego — OS będzie oddawał zasoby innym procesom
    // gdy Nitrix nie jest aktywny (skoki CPU przy ładowaniu stron w tle drastycznie maleją)
    try {
      const os = require('os')
      process.setPriority(process.pid, os.constants.priority.PRIORITY_BELOW_NORMAL)
    } catch(e) {}
    createWindow()
    setupAutoUpdater()
  }
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

// ── Przechwytuj wszystkie nowe okna/popupy — otwieraj jako nowa karta ──
app.on('web-contents-created', (e, wc) => {
  wc.setWindowOpenHandler(({ url }) => {
    if (!url || url === 'about:blank') return { action: 'deny' }
    if (!/^https?:\/\//i.test(url)) return { action: 'deny' }
    // Wyślij do okna które jest właścicielem tego webContents
    const win = BrowserWindow.fromWebContents(wc)
      ?? BrowserWindow.getFocusedWindow()
      ?? BrowserWindow.getAllWindows()[0]
    if (win && !win.isDestroyed()) win.webContents.send('open-in-new-tab', url)
    return { action: 'deny' }
  })
})

// ══════════════════════════════════════════════════════════════════════
//  AUTO-UPDATE
// ══════════════════════════════════════════════════════════════════════
function setupAutoUpdater() {
  // Nie sprawdzaj aktualizacji w trybie dev
  if (!app.isPackaged) return

  autoUpdater.autoDownload = false         // NIE pobieraj automatycznie — czekaj na żądanie użytkownika
  autoUpdater.autoInstallOnAppQuit = true  // zainstaluj przy zamknięciu

  let updateDismissed = false              // true = użytkownik kliknął "Może później" — nie pokazuj w tej sesji

  const getWin = () => BrowserWindow.getAllWindows()[0]

  autoUpdater.on('checking-for-update', () => {
    getWin()?.webContents.send('update-status', { status: 'checking' })
  })

  autoUpdater.on('update-available', info => {
    if (updateDismissed) return            // użytkownik już odrzucił — nie pokazuj ponownie
    getWin()?.webContents.send('update-status', {
      status: 'available',
      version: info.version,
    })
  })

  autoUpdater.on('update-not-available', () => {
    getWin()?.webContents.send('update-status', { status: 'not-available' })
  })

  autoUpdater.on('download-progress', progress => {
    getWin()?.webContents.send('update-status', {
      status: 'downloading',
      percent: Math.round(progress.percent),
      speed:   progress.bytesPerSecond,
    })
  })

  autoUpdater.on('update-downloaded', info => {
    getWin()?.webContents.send('update-status', {
      status: 'downloaded',
      version: info.version,
    })
  })

  autoUpdater.on('error', err => {
    getWin()?.webContents.send('update-status', {
      status: 'error',
      message: err.message,
    })
  })

  // Renderer prosi o rozpoczęcie pobierania
  ipcMain.on('update-download-now', () => {
    autoUpdater.downloadUpdate()
  })

  // Renderer prosi o restart i instalację
  ipcMain.on('update-install-now', () => {
    autoUpdater.quitAndInstall(false, true)
  })

  // Renderer odrzucił aktualizację — nie pokazuj w tej sesji
  ipcMain.on('update-dismiss', () => {
    updateDismissed = true
  })

  // Sprawdź aktualizacje po 3 sekundach od startu
  setTimeout(() => autoUpdater.checkForUpdates(), 3000)

  // Sprawdzaj co godzinę
  setInterval(() => autoUpdater.checkForUpdates(), 60 * 60 * 1000)
}